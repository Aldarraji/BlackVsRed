package com.example.final_aram;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.inputmethodservice.Keyboard;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

class ConnectView extends View {

    Context activityContext;

    private String tag = "AA";
    private int touchX;
    private int touchY;
    boolean iscolor[][];

    private final int XBASE = 40;
    private final int YBASE = 80;

    private final int BW = 40;
    private final int BH = 40;

    private final int ROWS = 5;
    private final int COLS = 5;

    private final int EMPTY = 11;
    private final int RED = 12;
    private final int BLACK = 13;
    private boolean game_over = false;

    private int status[][];

    Bitmap empty_image;
    Bitmap red_image;
    Bitmap black_image;

    private class RowCol {
        public int row;
        public int col;
    }

    private void print(String s) {
        Log.i(tag, s);
    }

    public ConnectView(Context context) {
        super(context);
        activityContext = context;

        status = new int[ROWS][COLS];

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                status[i][j] = EMPTY;
            }
        }

        empty_image = BitmapFactory.decodeResource(getResources(), R.mipmap.empty);
        red_image = BitmapFactory.decodeResource(getResources(), R.mipmap.red);
        black_image = BitmapFactory.decodeResource(getResources(), R.mipmap.black);
    }

    private RowCol getIndex(int x, int y)
    {
        RowCol rc = new RowCol();
        if ((x < XBASE) ||
                (x > BW * COLS + XBASE) ||
                (y < YBASE) ||
                (y > BH * ROWS + YBASE) ) {
            rc.row = -1;
            rc.col = -1;
            return rc;
        }
        rc.row = (y - YBASE) / BH;
        rc.col = (x - XBASE) / BW;
        print("getIndex: r = " + rc.row + ", c = " + rc.col);
        return rc;

    }

    //check if the red or black have 4 of the same rolor  in a row

    private int countNeighboringColor(int r, int c)
    {
        int count = 0;
        if ((r>0) && (c>0) && (iscolor[r-1][c-1])) count++;
        if ((r>0) && (iscolor[r-1][c])) count++;
        if ((r>0) && (c<COLS-1) && (iscolor[r-1][c+1])) count++;
        if ((c>0) && (iscolor[r][c-1])) count++;
        if ((c<COLS-1) && (iscolor[r][c+1])) count++;

        if ((r<ROWS-1) && (c>0) && (iscolor[r+1][c-1])) count++;
        if ((r<ROWS-1) && (iscolor[r+1][c])) count++;
        if ((r<ROWS-1) && (c<COLS-1) && (iscolor[r+1][c+1])) count++;
        return count;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if(game_over) return true;
        print("onTouchEvent");
        touchX = (int) e.getX();
        touchY = (int) e.getY();
        Paint fg = new Paint();
        int action = e.getAction();
        RowCol rc;
        rc = getIndex(touchX, touchY);

        int redCount2 = 0;
        int blackCount2 = 0;
        if (rc.row != -1 && rc.col != -1) {
            for (int Count2 = 0; Count2 < COLS; Count2++) {
                    print("in the loop");
                    if (blackCount2 > redCount2) {
                        print("red");
                        status[rc.row][rc.col] = RED;
                        redCount2 = blackCount2 + 1;
                        invalidate();
                        break;
                    }
                    if (redCount2 > blackCount2){
                        print("black");
                        status[rc.row][rc.col] = BLACK;
                        blackCount2 = redCount2 + 1;
                        invalidate();
                        break;
                    }
                    else {
                        print("else");
                        redCount2++;
                        //break;
                    }

            }
        }


        //return super.onTouchEvent(e);

        //check to see if the red or black won
        int redCount = 0;
        int blackCount = 0;
        if (game_over == false) {

            //loop to count left
            for (int i = 0; i < ROWS; i++) {
                for (int j = 0; j < COLS; j++) {
                    if (status[i][j] == RED) {
                        redCount++;
                    }
                    else if (status[i][j] == BLACK) {
                        blackCount++;
                    }
                }
            }

            //int n =countNeighboringColor(rc.row, rc.col);
            //check to see if winner
            if ((4 == redCount)) {
                String end = "Red Won!!!!";
                Toast.makeText(activityContext, end, Toast.LENGTH_LONG).show();
                game_over = true;
            }
            else if ((4 == blackCount)) {
                String end = "Black Won!!!!";
                Toast.makeText(activityContext, end, Toast.LENGTH_LONG).show();
                game_over = true;
            }
        }
        return super.onTouchEvent(e);
    }


    @Override
    public void onDraw(Canvas canvas) {

        Paint fg = new Paint();
        int w = getWidth();
        int h = getHeight();
        print("onDraw: w = " + w + ", h = " + h);

        canvas.drawColor(Color.WHITE);
        fg.setColor(Color.BLACK);

        int y = 0;
        y = (y - YBASE) / BH;
        int x = 0;
        x = (x - XBASE) / BW;

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (status[i][j] == EMPTY) {
                    //canvas.drawBitmap(empty_image, ixbase, ybase, null);
                    canvas.drawBitmap(empty_image, (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
                else if(status[i][j] == RED) {
                    canvas.drawBitmap(red_image,  (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
                else if(status[i][j] == BLACK)  {
                    canvas.drawBitmap(black_image,  (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
            }
        }
        fg.setStrokeWidth(2);
        // Horizontal Lines
        canvas.drawLine(XBASE - 2, YBASE - 2, COLS*BW + XBASE + 2, YBASE - 2, fg);
        canvas.drawLine(XBASE - 2, YBASE - 2, XBASE - 2, ROWS*BH + YBASE + 2, fg);

        // Vertical Lines
        canvas.drawLine(XBASE - 2, ROWS*BH + YBASE + 2, COLS*BW + XBASE + 2, ROWS*BH + YBASE + 2, fg);
        canvas.drawLine(COLS*BW + XBASE + 2, YBASE - 2, COLS*BW + XBASE + 2, ROWS*BH + YBASE + 2, fg);

        fg.setTextSize(24);
    }



}



public class MainActivity extends AppCompatActivity {

    private String tag = "AA";

    ConnectView connectView;
    private void print(String s)
    {
        Log.i(tag, s);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        print("onCreate:");
        Toast.makeText(this, "connect 4", Toast.LENGTH_SHORT).show();

        connectView = new ConnectView(this);
        setContentView(connectView);
    }
}
